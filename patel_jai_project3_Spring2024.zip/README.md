Name: Jai Patel
Section: Class #23321
UFL email: jpatel9@ufl.edu
System: Windows
Compiler: main.cpp
SFML version: 2.5.1
IDE: CLion
Other notes: None


